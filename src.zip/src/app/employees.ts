export class Employees {
    constructor(
        public id:number,
        public name:string,
        public location:string,
        public email:string,
        public mobile:number

    ){

    }
}
