import { Employees } from './employees';

describe('Employees', () => {
  it('should create an instance', () => {
    expect(new Employees()).toBeTruthy();
  });
});
